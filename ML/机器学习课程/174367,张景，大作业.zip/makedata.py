import pandas as pd
import numpy as np
import csv
from sklearn.preprocessing import OneHotEncoder


data = pd.read_table("../out100.csv",sep=',')
data = pd.DataFrame(data)
#1476633600时间戳转换为日期则是：2016/10/17 0:0:0
#1477065598是记录中最后一条数据，日期为：2016/10/21 23:59:58
#1小时 == 3600秒，一天为:86400秒
#一共5天时间，需要把连续的时间划分为离散的时间段：

# data['time'] = data['time'] - 1476633600
# print(data['hostgrpid'].value_counts())#hostname分组，一共435组,不存在分组id为0的情况
# print(data['Y_usrgrp_id'].value_counts())#列出不同分组人数
# print(data['hittimes'].value_counts())#列出一分钟内点击次数，过高可能是爬虫而非人为点击--160种

# print(data[data.Y_usrgrp_id==0])#寻找Y_id为0的那一条数据
# print(data[data.username=='*******24'])#查找该用户所有记录，发现只有一条数据

# print(len(data))

#

hostname_values = data['hostname']#处理hosname-分离出数据

# hostname_values.to_csv('hostname.csv',index=False)

def shorten_url(url):#去掉主机名后面的.com之类的
    # index1 = url.find('')
    # if index1 != -1:
    #     url = url[index1+4:]
    del_array = ['.com', '.net', '.cn','.gov']
    for del_name in del_array:
        index = url.find(del_name)
        if index != -1:
            url = url[:index]
            break
    return url
# short_data = pd.read_csv('../hostname_short.csv',header=None) or '.net' or '.cn' or '.gov'
def cutvalue(str1):#
    result = ""
    i = 0
    if '.' in str1:
        for index in range(1,len(str1)+1):
            if str1[-index-1]=='.':
               break
            else:
                i+=1
        result = str1[len(str1)-i-1:]
    else:
        result = str1

    return result
#
for index in range(len(data)):
    if ('.com' in hostname_values.loc[index]) or ('.net'in hostname_values.loc[index])\
            or ('.cn'in hostname_values.loc[index]) or ('.gov' in hostname_values.loc[index]):

        data['hostname'].loc[index] = cutvalue(shorten_url(data['hostname'].loc[index]))
    else:
        data.drop([index], inplace=True)
    if index%50 == 0:
        print(index)


data.drop([25738],inplace=True)#删除第25987行的异常值


# data.to_csv('out100.csv',index=False)


# url_list = pd.read_csv('./hostname.csv', header=None)

# for i in range(url_list[0].shape[0]):
# # for i in range(100):
#     url_list[0][i] = cutvalue(shorten_url(url_list[0][i]))
#     print(url_list[0][i])







#处理时间戳--分为四个世家段，映射为4个数字
for i in range(5):
    data.time[(data.time>=1476633600+i*86400) & (data.time<1476655200+i*86400)] = 1
    data.time[(data.time>=1476655200+i*86400) & (data.time<1476676800+i*86400)] = 2
    data.time[(data.time>=1476676800+i*86400) & (data.time<1476698400+i*86400)] = 3
    data.time[(data.time>=1476698400+i*86400) & (data.time<1476720000+i*86400)] = 4

#处理hostgrpid值，一共435组
hostgrpid_values = data['hostgrpid']#获取hostgrpid列
hostgrpid_values = list(hostgrpid_values)
hostgrpid_values = sorted(set(hostgrpid_values), key = hostgrpid_values.index)#删除列中重复元素
hostgrpid_values = sorted(hostgrpid_values)#获取到hostgrpid所有的值，并且排列
for index,item in enumerate(hostgrpid_values):
    data.hostgrpid[data.hostgrpid == item] = index+1

#处理mac地址--一共8种数据
mac_values = data['mac']
mac_values = list(mac_values)
mac_values = sorted(set(mac_values), key = mac_values.index)#得到data['mac']独一无二的值
for index,item in enumerate(mac_values):
    data.mac[data.mac == item] = index+1


#处理ip地址--一共90种数据
ip_values = data['ip']
ip_values = list(ip_values)
ip_values = sorted(set(ip_values), key = ip_values.index)#得到data['mac']独一无二的值
for index,item in enumerate(ip_values):
    data.ip[data.ip == item] = index+1


#处理username--84种数据
username_values = data['username']
username_values = list(username_values)
username_values = sorted(set(username_values), key = username_values.index)#得到data['mac']独一无二的值
for index,item in enumerate(username_values):
    data.username[data.username == item] = index+1

#处理hostname--84种数据
hostname_values = data['hostname']
hostname_values = list(hostname_values)
hostname_values = sorted(set(hostname_values), key = hostname_values.index)#得到data['mac']独一无二的值
for index,item in enumerate(hostname_values):
    data.hostname[data.hostname == item] = index+1


outdata = data[['time','username','ip','mac','hostgrpid','hostname','hittimes','Y_usrgrp_id']]
outdata.to_csv('outdata.csv', index=False)



