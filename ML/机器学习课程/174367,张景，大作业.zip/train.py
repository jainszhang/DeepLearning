import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder


data = pd.read_table("outdata.csv",sep=',')#读取数据
data = pd.DataFrame(data)#转换为Dataframe格式

print(data['Y_usrgrp_id'].value_counts())

from sklearn.model_selection import train_test_split
train = data[['time','mac','hostgrpid','hostname','hittimes']]
# train = data[['hostname']]
target = data['Y_usrgrp_id']


# res = train


#time one-hot编码
a = [[1],[2],[3],[4]]
b = np.array(data['time']).reshape((-1,1))
enc = OneHotEncoder()
enc.fit(a)
time_data = pd.DataFrame(enc.transform(b).toarray(),columns=[500,501,502,503])

# print(time_data.columns)



#hostgrpiddata one-hot encoder
list = []
for i in range(1,436):
    list.append(i)
a1 = np.array(list).reshape((-1,1)).tolist()
b1 = np.array(data['hostgrpid']).reshape((-1,1))
enc1 = OneHotEncoder()
enc1.fit(a1)
hostgrpid_data = pd.DataFrame(enc1.transform(b1).toarray(),columns=list)
# print(hostgrpid_data.columns)


#mac one-hot encoder
a2 = [[1],[2],[3],[4],[5],[6],[7],[8]]
b2 = np.array(data['time']).reshape((-1,1))
enc = OneHotEncoder()
enc.fit(a2)
mac_data = pd.DataFrame(enc.transform(b2).toarray(),columns=[505,506,507,508,509,510,511,512])
# print(mac_data.columns)


#hostname one-hot encoder
column3 = []
for i in range(601,982):#存储列标号
    column3.append(i)
# print(column3)

list3 = []
for i in range(1,382):
    list3.append(i)
a3 = np.array(list3).reshape((-1,1)).tolist()
b3 = np.array(data['hostname']).reshape((-1,1))
enc3 = OneHotEncoder()
enc3.fit(a3)
hostname_data = pd.DataFrame(enc3.transform(b3).toarray(),columns=column3)
# print(hostname_data.columns)


#hittimes不需要one-hot
hittimes_data = data['hittimes']


#连接数据
res = pd.concat([time_data,mac_data,hostgrpid_data,hostname_data,hittimes_data],axis=1)
res = pd.DataFrame(res)
del data


#训练模型

from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import cross_val_score

train_X,test_X, train_y, test_y = train_test_split(res,
                                                   target,
                                                   test_size = 0.25,
                                                   random_state = 0)

# xgbc = XGBClassifier(learning_rate=0.05,n_estimators=500,min_child_weight=5)
xgbc = XGBClassifier(
 learning_rate =0.05,
 n_estimators=3000,
 max_depth=4,
 min_child_weight=6,
 gamma=0,
 subsample=0.8,
 colsample_bytree=0.8,
 objective= 'multi:softmax ',
 nthread=4,
scale_pos_weight=1,
seed=27)
gbc = xgbc.fit(train_X,train_y,eval_set=[(train_X,train_y)],early_stopping_rounds=100)
acc = xgbc.score(test_X,test_y)
print(acc)

target_names = ['class 0', 'class 1', 'class 2','class 3']
pre_y = xgbc.predict(test_X)
print(classification_report(test_y, pre_y, target_names=target_names))


